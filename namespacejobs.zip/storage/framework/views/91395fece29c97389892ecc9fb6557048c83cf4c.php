<?php if(auth()->guard()->check()): ?>
<?php if(Auth::user()->company()): ?>
<a href="<?php echo e(route('job.create')); ?>" class="btn btn-block btn-info">Post new job</a>
<?php endif; ?>
<?php if(Auth::user()->applicant()): ?>
<a href="<?php echo e(route('profile.edit')); ?>" class="btn btn-block btn-info">Edit Profile</a>

<a href="<?php echo e(route('job.all')); ?>" class="btn btn-block btn-info">Find jobs</a>
<?php endif; ?>
<?php endif; ?>



<?php /**PATH C:\xampp\htdocs\NamespaceJobs\resources\views/inc/sidebar.blade.php ENDPATH**/ ?>