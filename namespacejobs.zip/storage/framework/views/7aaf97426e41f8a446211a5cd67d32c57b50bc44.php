<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <div class="card-header">Update Your Profile Info</div>

        <div class="card-body">
            <?php echo $__env->make('inc.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <form method="post" action="<?php echo e(route('profile.update')); ?>"  enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label>Change Profile Picture</label>
                    <input type="file" name="picture" >
                </div>
                <div class="form-group">
                    <label>Change Resume</label>
                    <input type="file" name="resume" >
                </div>
                <div class="form-group">
                    <label>Skills</label>
                    <input type="text" name="skills" class="form-control" value="<?php
                                if(old('skills'))
                                echo old('skills');
                                else 
                                echo $profile->skills;
                                ?>" >
                </div>
                <input type="submit" name="submit" class="btn btn-primary">
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NamespaceJobs\resources\views/profile/edit.blade.php ENDPATH**/ ?>