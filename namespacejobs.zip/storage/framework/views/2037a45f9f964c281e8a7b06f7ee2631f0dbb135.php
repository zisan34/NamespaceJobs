<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-3">
            <?php echo $__env->make('inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-md-9">
            <div class="card">
                <div class="card-header">
                <?php if(auth()->guard()->check()): ?>

                <?php if(Auth::user()->company()): ?>
                Previously Posted Jobs
                <?php endif; ?>
                <?php if(Auth::user()->applicant()): ?>
                Previously Applied Jobs
                <?php endif; ?>

                <?php endif; ?>
                </div>

                <div class="card-body">
                    <?php echo $__env->make('inc.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                <?php if(auth()->guard()->check()): ?>
                <?php if(Auth::user()->company()): ?>

                    <?php if(count(Auth::user()->jobs)>0): ?>
                    <ul>
                    <?php $__currentLoopData = Auth::user()->jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($job->job_title); ?>

                        <ul>
                            <?php if(count($job->jobApplications)>0): ?>
                            Applicants: <br>
                            <?php $__currentLoopData = $job->jobApplications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobApplication): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(route('profile.view',['id'=>encrypt($jobApplication->user->id)])); ?>"><?php echo e($jobApplication->user->first_name); ?>&nbsp;<?php echo e($jobApplication->user->last_name); ?></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </ul>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <?php endif; ?>

                <?php endif; ?>

                <?php if(Auth::user()->applicant()): ?>

                    <?php if(count(Auth::user()->jobApplications)>0): ?>

                    <ul>
                    <?php $__currentLoopData = Auth::user()->jobApplications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jobApplication): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <?php echo e($jobApplication->job->job_title); ?>

                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>

                    <?php endif; ?>


                <?php endif; ?>
                <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NamespaceJobs\resources\views/home.blade.php ENDPATH**/ ?>