<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <div class="card-header">All available jobs</div>

        <div class="card-body">
            <?php echo $__env->make('inc.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php if(count($jobs)>0): ?>
            <ul>
            <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <?php echo e($job->job_title); ?>

                <ul>
                    <li>Description:<?php echo e($job->job_description); ?></li>
                    <li>Salary:<?php echo e($job->salary); ?></li>
                    <li>Location:<?php echo e($job->location); ?>,<?php echo e($job->country); ?></li>
                </ul>
            </li>
            <a href="<?php echo e(route('job.apply',['job_id'=>encrypt($job->id)])); ?>" class="btn btn-primary">Apply for this job</a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NamespaceJobs\resources\views/job/all.blade.php ENDPATH**/ ?>