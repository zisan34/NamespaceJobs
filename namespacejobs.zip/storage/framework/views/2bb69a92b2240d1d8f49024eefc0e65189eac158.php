<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="card">
        <div class="card-header">Profile Info of <?php echo e($profile->user->first_name); ?></div>

        <div class="card-body">
            <div class="row">
                <div class="col-sm-3">First Name:</div>
                <div class="col-sm-9">
                    <?php echo e($profile->user->first_name); ?>

                </div>
            </div>
            <div class="row">
                <div class="col-sm-3">Last Name:</div>
                <div class="col-sm-9">
                    <?php echo e($profile->user->last_name); ?>

                </div>
            </div>
            <div class="row">
                <div class="col-sm-3">Profile Picture:</div>
                <div class="col-sm-9">
                    <img src="<?php echo e(asset($profile->profile_picture)); ?>" height="200px" width="200px">
                </div>
            </div>
            <div class="row">
                <div class="col-sm-3">Resume:</div>
                <div class="col-sm-9">
                    <embed src="<?php echo e(asset($profile->resume)); ?>" style="width:600px; height:800px;" frameborder="0">

                    
                </div>
            </div>

            <div class="row">
                <div class="col-sm-3">Skills:</div>
                <div class="col-sm-9">
                    <?php echo e($profile->skills); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\NamespaceJobs\resources\views/profile/view.blade.php ENDPATH**/ ?>